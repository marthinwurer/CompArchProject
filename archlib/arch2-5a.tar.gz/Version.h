// Version.h
//
// Warren R. Carithers
//	December 1999

/*
 * Internal version number
 */

#ifndef _VERSION_H_
#define _VERSION_H_

using namespace std;

const char * VERSION = "2.5a";

#endif
